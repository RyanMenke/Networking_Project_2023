import java.io.File;
import java.util.ArrayList;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Main {
    public static void main(String[] args) {



        ///////////////////////////////////////////////////
        //first I did some basic testing in my code///////
        //this will not be in the final in the same form//
        //////////////////////////////////////////////////




        //This is an array of "peers"
        //they will be the ones sharing file information



        ArrayList<Peer> peers = new ArrayList<>();

        FileReader.readPeerInfoFile(peers);




        for (int i = 0; i < peers.size(); i++) {


            peers.get(i).printContents();


        }

        PeerConfiguration config = new PeerConfiguration();
        FileReader.readConfigInfo(config);
        config.printConstents();

        String currentWorkingDirectory = System.getProperty("user.dir");
        System.out.println("Current working directory: " + currentWorkingDirectory);

        //First, you need to get the current working directory, which is the directory where you
        //start the Java program, as follows:
        // String workingDir = System.getProperty("user.dir");
        //Second, you invoke exec() method as in the following:
        // Runtime.getRuntime().exec("ssh " + hostname + " cd " + workingDir + " ; " +
        //peerProcessName + " " + peerProcessArguments );

    }
}
