import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class Peer {

    //peer variables
    private int peerId;
    private String hostName;
    private int portNumber;
    private boolean hasFile;

    private boolean remainOpen;

    //connection variables
    Socket socket;
    InputStream inputStream;
    OutputStream outputStream;
    BufferedReader bufferedReader;
    PrintWriter printWriter;


    public Peer(int Id, String hName, int pNumber, boolean hFile) {
        peerId = Id;
        hostName = hName;
        portNumber = pNumber;
        hasFile = hFile;

        remainOpen = true;
    }

    public void printContents() {
        System.out.println("");
        System.out.println(peerId);
        System.out.println(hostName);
        System.out.println(portNumber);
        System.out.println(hasFile);
        System.out.println("");
    }

    public int getPeerId() {

        return peerId;

    }

    public String getHostName() {

        return hostName;

    }

    public int getPortNumber() {

        return portNumber;

    }

    public Boolean hasFile() {

        return hasFile;

    }

    public void runProcess(PeerConfiguration config) {
        if (peerId == 1001) {
        }

        while (remainOpen) {

        }
    }

    //First Peer:
    //This peer also finds out that it is the first
    //peer; it will just listen on the port 6008 as specified in the file. Being the first peer, there
    //are no other peers to make connections to.


    //handshake:
    //32 bytes
    //header | zero bits | Peer Id
    //Header: 18 byte string "P2PFILESHARINGPROJ"
    //zero bits: 10 bytes
    //Peer ID: 4 bytes, integer ID


    //Actual Message
    //Length | Type | Payload
    //Length: 4 bytes, conveys length of message (minus the actual length field)
    //Type: 1 byte (0-7) is the type of message
    //Payload:a payload of variable length

    //Message Types:
    //0 | Choke
    //1 | Unchoke
    //2 | Interested
    //3 | Not Interested
    //4 | Have
    //5 | Bitfield
    //6 | request
    //7 | piece
}
