import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class FileReader {
    static void readPeerInfoFile(ArrayList<Peer> peers) {

        // Path of file to read
        String filePath = "project_config_file/PeerInfo.cfg";

        try {
            // Create a File object
            File file = new File(filePath);

            // Check if the file exists
            if (!file.exists()) {
                System.out.println("The file does not exist.");
                return;
            }

            // Create a FileInputStream to read the file
            FileInputStream fileInputStream = new FileInputStream(file);

            // Create a BufferedReader to efficiently read the file
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));

            String line;


            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                //System.out.println(parts[0]);  // Access the first part
                //System.out.println(parts[1]);  // Access the second part
                //System.out.println(parts[2]);
                boolean b = (Integer.parseInt(parts[3]) == 1);
                Peer p = new Peer(Integer.parseInt(parts[0]), parts[1], Integer.parseInt(parts[2]), b);
                peers.add(p);

                //System.out.println(line);
            }

            // Close the resources when done
            reader.close();
            fileInputStream.close();
            return;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static void readConfigInfo(PeerConfiguration config) {
        // Specify the path to the file you want to read
        String filePath = "project_config_file/Common.cfg";

        try {
            // Create a File object
            File file = new File(filePath);

            // Check if the file exists
            if (!file.exists()) {
                System.out.println("The file does not exist.");
                return;
            }

            // Create a FileInputStream to read the file
            FileInputStream fileInputStream = new FileInputStream(file);

            // Create a BufferedReader to efficiently read the file
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));

            String line;

            ArrayList<String> temp = new ArrayList<>();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                //System.out.println(parts[0]);  // Access the first part
                System.out.println(parts[1]);  // Access the second part
                //System.out.println(parts[2]);
                temp.add(parts[1]);

                System.out.println(line);
            }
            System.out.println(Integer.parseInt(temp.get(0)));
            System.out.println(temp.get(1));
            System.out.println(temp.get(2));
            System.out.println(temp.get(3));
            System.out.println(temp.get(4));
            config.setValues(
                    Integer.parseInt(temp.get(0)),
                    Integer.parseInt(temp.get(1)),
                    Integer.parseInt(temp.get(2)),
                    temp.get(3),
                    Integer.parseInt(temp.get(4)),
                    Integer.parseInt(temp.get(5))
            );

            // Close the resources when done
            reader.close();
            fileInputStream.close();
            return;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
